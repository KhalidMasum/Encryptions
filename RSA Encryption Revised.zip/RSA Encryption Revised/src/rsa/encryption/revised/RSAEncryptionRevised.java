/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rsa.encryption.revised;



/**
 *
 * @author Labnan
 */
public class RSAEncryptionRevised {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        KeyGeneration keygen = new KeyGeneration(5,11);
        keygen.makeEncryptKey();
        keygen.makeDecryptKey();
        System.out.println(keygen.encryptKey);
        System.out.println(keygen.decryptKey);
        System.out.println(keygen.commonkey);
       
        Cryptor cryptor = new Cryptor();
        cryptor.message= "A quick brown fox";
        cryptor.commonKey=keygen.commonkey;
        cryptor.encrypt(keygen.encryptKey);
        cryptor.decrypt(keygen.decryptKey);

                
        
        
        
    }
    
}
