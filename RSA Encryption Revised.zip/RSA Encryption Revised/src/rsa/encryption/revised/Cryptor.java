/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rsa.encryption.revised;

import java.util.Scanner;

/**
 *
 * @author Labnan
 */
public class Cryptor {
    double commonKey;
    Scanner sc = new Scanner(System.in);
    double[] collectorArray; 
    char[] charArray;
    String message;
   
    void setMessage(String message)
    {
        this.message = message;
    }
   
    void encrypt(double encryptionKey)
    {
        //message=message.toUpperCase();
        charArray= message.toCharArray();
       
        int i=0;
        for(double encryptedCharacters: charArray)
        {
            
          //  System.out.println (encryptedCharacters+" "+commonKey);
            encryptedCharacters=encryptALetter(encryptedCharacters,encryptionKey);
            //collectorArray[i]= characters;
            System.out.print(encryptedCharacters+" ");
            
            i++;
        
        }
        System.out.println("-3.0");

//message= new String (collectorArray);
    }
    void decrypt(double decryptionKey)
    {
        double plainDouble,encryptedDouble;
       do
        {
           encryptedDouble= sc.nextDouble();
          plainDouble= ((Math.pow(encryptedDouble,decryptionKey)%commonKey));
            System.out.print((plainDouble) +" ");
         
        }
        
        while(encryptedDouble!=-3.0);
    
    
    }
   double encryptALetter(double letter,double key)
    {
        double encryptedLetter;
        encryptedLetter=Math.pow(letter, key);
        encryptedLetter%=commonKey;
      //  System.out.println(encryptedLetter);
        return encryptedLetter;
    }
}
    
    
    

