/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rsa.encryption.revised;

import java.math.BigInteger;
import java.util.Scanner;

/**
 *
 * @author Labnan
 */
public class Cryptor {

    long commonKey;
    Scanner sc = new Scanner(System.in);
    long[] collectorArray;
    char[] charArray;
    String message;

    void setMessage(String message) {
        this.message = message;
    }

    void encrypt(long encryptionKey) {
        message=message.toUpperCase();
        charArray = message.toCharArray();

        int i = 0;
        for (long encryptedCharacters : charArray) {

            //  System.out.println (encryptedCharacters+" "+commonKey);
            encryptedCharacters = encryptALetter(encryptedCharacters, encryptionKey);///****-64
            //collectorArray[i]= characters;
            System.out.print(encryptedCharacters + " ");

            i++;

        }
        System.out.println("-3");

//message= new String (collectorArray);
    }

    void decrypt(long decryptionKey) {
        long plainLongOfCharacter, encryptedDouble;
        do {
            encryptedDouble = sc.nextLong();
            plainLongOfCharacter= decryptALetter(encryptedDouble, commonKey); //plainDouble = ((Math.pow(encryptedDouble, decryptionKey) % commonKey));
            if(encryptedDouble==-3) break;
            System.out.print((plainLongOfCharacter+55) + " ");//////////////////////**+64

        } while (true);

    }

    long encryptALetter(long letter, long key) {
        BigInteger bigLetter = BigInteger.valueOf((long) letter);
        bigLetter = bigLetter.pow((int) key);
        bigLetter = bigLetter.mod(BigInteger.valueOf((long) commonKey)); 

        return bigLetter.longValue();
    }

    long decryptALetter(long encryptedLetter, long key) {
        BigInteger bigLetter, bigEncryptedLetter, bigKey;
        bigEncryptedLetter = BigInteger.valueOf((long) encryptedLetter);

        bigLetter = bigEncryptedLetter.pow((int) key);

        bigLetter = bigLetter.mod(BigInteger.valueOf((long) commonKey)); 

        return bigLetter.longValue();

    }
}
